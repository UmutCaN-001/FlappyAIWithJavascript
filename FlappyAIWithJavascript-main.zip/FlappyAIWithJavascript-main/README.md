# FlappyAIWithJavascript

Actually you dont need to run on Node.js. So you have to download just public folder and simply click the index.html.
NeuralNetwork and Matrix class was taken from The Coding Train.
